package com.example.news.response

data class Source(
    val id: Any,
    val name: String
)